/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexfile;

/**
 *
 * @author idea
 */


import java.util.ArrayList;
// stores meta data information key value paiir etc
public class persist {

	private ArrayList<String> key;
	private ArrayList<String> value;
	
	
	public persist()
	{
		key = new ArrayList<String>();
		value = new ArrayList<String>();
	}
	
	public void put(String key,String value)
	{
		this.key.add(key);
		this.value.add(value);
	}
	
	public int getLength()
	{
		return key.size();
	}
	
	public String getKeyAt(int index)
	{
		return key.get(index);
	}
	public String getValueAt(int index)
	{
		return value.get(index);
	}
	
	
	
}
