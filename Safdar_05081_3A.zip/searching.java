/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexfile;

/**
 *
 * @author idea
 */



import java.util.Scanner;

//checks contents of the files in index and give directory i.e serves using threads
public class searching implements Runnable {

	private Scanner sc;
	
	@Override
	public void run() {

		print("Give sentence to search");
		
		Boolean keepGoing = true;
		sc = new Scanner(System.in);
		
		while(keepGoing)
		{
			print("What do you want to search give String press 0 to quit!: ");
			String text = sc.nextLine();
			if(text.equalsIgnoreCase("0"))
				keepGoing = false;
			else
			{
				search(text);
				
			}
		}
	}
	
	
	
	

	private void print(String print)
	{
		System.out.println(print);
	}
	

	public void search(String text) {
		Boolean found = false;
		persist map = crawler.map;
		for(int i = 0 ; i < map.getLength(); i++)
		{
			if(map.getKeyAt(i).equalsIgnoreCase(text)){
				print(" It is found in: " + map.getValueAt(i)); 
				found = true;
			}
			
		}
		
		if(!found)
			print("String is not found");
	}
}
