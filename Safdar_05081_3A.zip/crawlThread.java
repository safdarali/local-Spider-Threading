/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexfile;

/**
 *
 * @author idea
 */


import java.io.File;

//crawls the directories using threads i.e multithreads and daemon threads
public class crawlThread extends Thread {


	private String PATH;
	public static int threadCount;
	
	public crawlThread(String path)
	{
		this.PATH = path;
	}
	
	public void run()
	{
		threadCount++;
		
		craweler(new File(PATH));
		threadCount--;
	}
	
	public void craweler(File root)
	{
		File[] file = root.listFiles();
		for(int i = 0; i < file.length ; i++)
		    if(file[i].isDirectory())
		    {
		    	if(threadCount < 5)
		    	{
		    		crawlThread thread = new crawlThread(file[i].getAbsolutePath());
		    		thread.run();
		    	}
		    	else
		    	{
		    		
		    		craweler(file[i]);
		    	}
		    }
		    else
		    {
		    	if(file[i].getName().contains(".txt")){
		    		crawler.filesTobeIndexed.add(file[i]);
		    	}
		    }
	}
}
