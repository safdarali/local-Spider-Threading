/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexfile;

/**
 *
 * @author idea
 */


import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.nio.file.Files;


//used for indexing
//used for indexing with maps and arrayLists with multi threads
public class IndexFile implements Runnable {

	

	public void run()
	{
		while(true)
		{
			if(crawler.filesTobeIndexed.size() == 0)
			{
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) {
					
				}
			}
			else
			{
				ArrayList<File> filesTobeIndexed = new ArrayList<File>();
				for(int i = 0; i < 
				crawler.filesTobeIndexed.size(); i++)
				{
					filesTobeIndexed.add(crawler.filesTobeIndexed.get(i));
				}
				crawler.filesTobeIndexed.clear();
				
				for(int i = 0; i < filesTobeIndexed.size(); i++)
				{
					index(filesTobeIndexed.get(i));
				}
				
			}
		}
	}
	
	private synchronized void index(File file) 
	{
		try
		{
			List<String> lines = Files.readAllLines(Paths.get(file.getAbsolutePath()),StandardCharsets.UTF_8);
			for(String line: lines)
			{
				String[] words = line.split(" ");
				for(String s: words)
				{
					crawler.map.put(s, file.getAbsolutePath());
				}
			}
		}
		catch(IOException e)
		{
			
		}
	}
}
