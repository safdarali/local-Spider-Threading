/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexfile;

/**
 *
 * @author idea
 */


import java.io.File;
import java.util.ArrayList;

//Main class that crawls the directories
public class crawler 
{
	public static final String parentDirectory = "/home/idea/Desktop/directory";
	static persist map;
	static ArrayList<File> filesTobeIndexed;
	

	
	public crawler()
	{
		 map = new persist();
		 filesTobeIndexed = new ArrayList<File>();
	}
	
	
	public static void main(String [] args)
	{
		crawler crawler = new crawler();
		crawler.start();
	}

	public void start() 
	{
		
		
		Thread thread = new crawlThread(parentDirectory);
		thread.setDaemon(true);
		thread.start();

		Thread indexerThread = new Thread(new IndexFile());
		indexerThread.setDaemon(true);
		indexerThread.start();
	
		Thread searching = new Thread(new searching());
		searching.start();
		
		try {
			thread.join();
			searching.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
			
		
	}
	
	
	public void StartTest()
	{
                
		
		Thread thread = new crawlThread(parentDirectory);	
		thread.setDaemon(true);						
		thread.start();							

		Thread indexerThread = new Thread(new IndexFile());		
		indexerThread.setDaemon(true);							
		indexerThread.start();									

		try {
			thread.join();								
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	public int search(String text) {
		Boolean found = false;
		int results = 0;
		for(int i = 0 ; i < map.getLength(); i++)
		{
			if(map.getKeyAt(i).equalsIgnoreCase(text)){
				print(" It is found in: " + map.getValueAt(i)); 
				found = true;
				results++;
				}
		}
		
		if(!found)
			print("Search is not found in files");
		
		return results;
	}

	private void print(String print)
	{
		System.out.println(print);
	}
	
	
}
