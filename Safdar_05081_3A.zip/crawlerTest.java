/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexfile;

import java.io.File;
import org.junit.Test;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author idea
 */
public class crawlerTest {
    
    public crawlerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    @Test
    //check whether parent directory exists or not
    public void testSearch() {
                File file = new File(crawler.parentDirectory);
		if(!file.exists())
			fail("No path exists");
    }
     @Test
     //check the search index and crawler
    public void testCrawler() {
                
                String wordToSearch = "safdar";
		
		crawler craw = new crawler();
		craw.StartTest();
		if(crawler.map.getLength() < 1)
			fail("No word is not found");
		
		if(craw.search(wordToSearch) < 1)
			fail("Not found");
        
        
    }
    
    
    
}
